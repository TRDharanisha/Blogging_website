<footer class="footer">
  <p>BLOGGING WEBSITE BLOGO</p>
</footer>

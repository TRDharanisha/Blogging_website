<?php

include '../components/connect.php';

session_start();

if(isset($_POST['submit'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);

   // Check if the username already exists
   $select_creator = $conn->prepare("SELECT * FROM `creator` WHERE name = ?");
   $select_creator->execute([$name]);

   if($select_creator->rowCount() > 0){
      $message[] = 'Username already taken!';
   }else{
      // Insert new creator
      $insert_creator = $conn->prepare("INSERT INTO `creator`(name, password) VALUES(?, ?)");
      $insert_creator->execute([$name, $pass]);

      if($insert_creator){
         $_SESSION['admin_id'] = $conn->lastInsertId();
         header('location:creator_dashboard.php');
      }else{
         $message[] = 'Registration failed, please try again!';
      }
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body style="padding-left: 0 !important;">

<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<section class="form-container">
   <form action="" method="POST">
   <h2><a href="http://localhost/blogging%20website/project/" style="text-align: left; display: block;">Back</a></h2>
   <h3>Register now</h3>
      <input type="text" name="name" required placeholder="enter your name" class="box" maxlength="50">
      <input type="email" name="email" required placeholder="enter your email" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="pass" required placeholder="enter your password" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="cpass" required placeholder="confirm your password" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="register now" name="submit" class="btn">
      <p>Already have an account? <a href="creator_login.php">Login now</a></p>
   </form>
</section>

</body>
</html>

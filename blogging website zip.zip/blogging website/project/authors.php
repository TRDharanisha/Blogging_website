<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/like_post.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Authors</title>

   <!-- font awesome cdn link -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- Authors section starts -->

<section class="authors">

   <h2><a href="home.php" style="text-align: left; display: block;">Back</a></h2>
   <h1 class="heading">Authors</h1>

   <div class="box-container">

   <?php
      $select_authors = $conn->prepare("SELECT * FROM `admin`");
      $select_authors->execute();
      if($select_authors->rowCount() > 0){
         while($fetch_authors = $select_authors->fetch(PDO::FETCH_ASSOC)){ 

            $admin_id = $fetch_authors['id']; 
            
            // Count posts by author
            $count_posts = $conn->prepare("SELECT COUNT(*) FROM `posts` WHERE admin_id = ?");
            $count_posts->execute([$admin_id]);
            $total_posts = $count_posts->fetchColumn();

            // Count likes by author
            $count_likes = $conn->prepare("SELECT COUNT(*) FROM `likes` WHERE admin_id = ?");
            $count_likes->execute([$admin_id]);
            $total_likes = $count_likes->fetchColumn();

            // Count comments by author
            $count_comments = $conn->prepare("SELECT COUNT(*) FROM `comments` WHERE admin_id = ?");
            $count_comments->execute([$admin_id]);
            $total_comments = $count_comments->fetchColumn();
   ?>
   <div class="box">
      <p>Author ID : <span><?= $admin_id; ?></span></p>
      <p>Username : <span><?= htmlspecialchars($fetch_authors['name']); ?></span></p>
      <p>Total posts : <span><?= $total_posts; ?></span></p>
      <p>Total likes : <span><?= $total_likes; ?></span></p>
      <p>Total comments : <span><?= $total_comments; ?></span></p>
   </div>
   <?php
      }
   }else{
      echo '<p class="empty">No authors available.</p>';
   }
   ?>

   </div>

</section>

<!-- Authors section ends -->

<!-- custom js file link -->
<script src="js/script.js"></script>

</body>
</html>
